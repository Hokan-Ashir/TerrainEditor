please refer to the comments in the shader files for license details
