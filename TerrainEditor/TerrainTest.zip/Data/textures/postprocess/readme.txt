noise2.png from nvidia shader library
http://developer.download.nvidia.com/shaderlibrary/webpages/shader_library.html

pencil.png based on the work of Shawn Hargreaves
http://www.talula.demon.co.uk/postprocessing/postprocessing.html

water.png taken from sauerbraten (author not known)
http://sauerbraten.org

other textures by tbw
The textures are free for non-commercial and commercial use. You're free to use and modify them.
Attribution would be nice.